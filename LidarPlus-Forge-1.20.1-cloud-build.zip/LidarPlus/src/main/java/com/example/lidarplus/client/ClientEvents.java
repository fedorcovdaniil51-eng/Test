package com.example.lidarplus.client;

import com.example.lidarplus.LidarPlus;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid=LidarPlus.MODID, value=Dist.CLIENT, bus=Mod.EventBusSubscriber.Bus.MOD)
public class ClientEvents {
    public static final KeyMapping OPEN_MENU = new KeyMapping("key.lidarplus.open", GLFW.GLFW_KEY_J, "key.categories.lidarplus");
    @SubscribeEvent public static void registerKeys(RegisterKeyMappingsEvent event) { event.register(OPEN_MENU); }
    @Mod.EventBusSubscriber(modid=LidarPlus.MODID, value=Dist.CLIENT, bus=Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeEvents {
        @SubscribeEvent public static void onClientTick(TickEvent.ClientTickEvent event) {
            if(event.phase != TickEvent.Phase.END) return;
            Minecraft mc=Minecraft.getInstance();
            while(OPEN_MENU.consumeClick()) {
                if(mc.player != null && mc.screen == null) mc.setScreen(new ScannerScreen());
            }
        }
    }
}
