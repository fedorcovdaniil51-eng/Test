package com.example.lidarplus.client;

import com.example.lidarplus.network.LidarNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.components.Button;

public class ScannerScreen extends Screen {
    public ScannerScreen() { super(Component.literal("LiDAR x180 — Control")); }
    @Override protected void init() {
        int cx = width / 2; int top = height / 2 - 82; int bw = 170; int x = cx - bw/2;
        addRenderableWidget(Button.builder(Component.literal("▶ Сканировать окружение"), b -> { LidarNetwork.send(0); }).bounds(x, top, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("⬆ Улучшить сканер (редстоун)"), b -> { LidarNetwork.send(1); }).bounds(x, top+25, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("♫ Вставить пластинку"), b -> { LidarNetwork.send(2); }).bounds(x, top+50, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("♫ Воспроизвести"), b -> { LidarNetwork.send(3); }).bounds(x, top+75, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Извлечь пластинку"), b -> { LidarNetwork.send(4); }).bounds(x, top+100, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> onClose()).bounds(x, top+130, bw, 20).build());
    }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int cx=width/2; int top=height/2-112;
        g.fill(cx-126,top,cx+126,top+256,0xE9101722);
        g.fill(cx-126,top,cx+126,top+2,0xFF39D9F5);
        g.drawCenteredString(font,"LiDAR x180 // FIELD CONSOLE",cx,top+12,0xFF64E8FF);
        g.drawCenteredString(font,"Сканер • Модули • Аудиослот",cx,top+27,0xFFB8DDE8);
        g.drawCenteredString(font,"Улучшения I–V: увеличивают радиус",cx,top+221,0xFFB8DDE8);
        g.drawCenteredString(font,"Пластинка хранится внутри сканера",cx,top+234,0xFFB8DDE8);
        super.render(g,mouseX,mouseY,partialTick);
    }
    @Override public boolean isPauseScreen() { return false; }
}
