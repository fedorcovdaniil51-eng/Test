package com.example.lidarplus.network;

import com.example.lidarplus.LidarPlus;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.RecordItem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraft.resources.ResourceLocation;
import java.util.function.Supplier;

public final class LidarNetwork {
    private static final String VERSION = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation(LidarPlus.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);
    public static void init() { CHANNEL.registerMessage(0, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle); }
    public static void send(int action) { CHANNEL.sendToServer(new ActionPacket(action)); }
    public record ActionPacket(int action) {
        static void encode(ActionPacket p, FriendlyByteBuf b) { b.writeVarInt(p.action); }
        static ActionPacket decode(FriendlyByteBuf b) { return new ActionPacket(b.readVarInt()); }
        static void handle(ActionPacket p, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player == null) return;
                ItemStack scanner = findScanner(player);
                if (scanner.isEmpty()) { player.sendSystemMessage(Component.literal("[LiDAR] Возьми сканер в инвентарь.")); return; }
                switch (p.action) {
                    case 0 -> scan(player, scanner);
                    case 1 -> upgrade(player, scanner);
                    case 2 -> insertDisc(player, scanner);
                    case 3 -> playDisc(player, scanner);
                    case 4 -> ejectDisc(player, scanner);
                }
            });
            ctx.setPacketHandled(true);
        }
    }
    private static ItemStack findScanner(ServerPlayer p) {
        for (ItemStack s : p.getInventory().items) if (s.is(com.example.lidarplus.LidarPlus.SCANNER.get())) return s;
        for (ItemStack s : p.getInventory().offhand) if (s.is(com.example.lidarplus.LidarPlus.SCANNER.get())) return s;
        return ItemStack.EMPTY;
    }
    private static int level(ItemStack s) { return s.getOrCreateTag().getInt("LidarLevel"); }
    private static void scan(ServerPlayer p, ItemStack s) {
        int lvl = level(s); int radius = 12 + lvl * 8;
        int entities = p.level().getEntities(p, p.getBoundingBox().inflate(radius)).size();
        int blocks = 0;
        var origin = p.blockPosition();
        int scanRadius = Math.min(4 + lvl * 2, 10);
        for (int x=-scanRadius;x<=scanRadius;x++) for(int y=-scanRadius;y<=scanRadius;y++) for(int z=-scanRadius;z<=scanRadius;z++) {
            var pos = origin.offset(x,y,z); if (!p.level().isLoaded(pos)) continue;
            if (!p.level().getBlockState(pos).isAir()) blocks++;
        }
        p.sendSystemMessage(Component.literal("§b[LiDAR] Сканирование завершено. Уровень: " + (lvl+1) + " | Радиус обнаружения: " + radius + " блоков | Объектов рядом: " + entities + " | Твёрдых блоков в секторе: " + blocks));
    }
    private static void upgrade(ServerPlayer p, ItemStack s) {
        int lvl = level(s);
        if (lvl >= 4) { p.sendSystemMessage(Component.literal("§e[LiDAR] Максимальный уровень улучшений уже установлен.")); return; }
        int cost = 4 + lvl * 4;
        int available = p.getInventory().items.stream().filter(st -> st.is(net.minecraft.world.item.Items.REDSTONE)).mapToInt(ItemStack::getCount).sum();
        if (!p.isCreative() && available < cost) {
            p.sendSystemMessage(Component.literal("§c[LiDAR] Нужно редстоуна: " + cost)); return;
        }
        if (!p.isCreative()) removeItems(p, net.minecraft.world.item.Items.REDSTONE, cost);
        s.getOrCreateTag().putInt("LidarLevel", lvl+1);
        p.sendSystemMessage(Component.literal("§a[LiDAR] Улучшение установлено! Уровень " + (lvl+2) + "/5. Радиус сканирования увеличен."));
    }
    private static void removeItems(ServerPlayer p, net.minecraft.world.item.Item item, int count) {
        int left=count; for (int i=0;i<p.getInventory().items.size() && left>0;i++) { ItemStack s=p.getInventory().items.get(i); if(s.is(item)){int n=Math.min(left,s.getCount());s.shrink(n);left-=n;} }
    }
    private static void insertDisc(ServerPlayer p, ItemStack scanner) {
        if (scanner.getOrCreateTag().contains("LidarDisc")) { p.sendSystemMessage(Component.literal("§e[LiDAR] Слот занят. Сначала извлеки пластинку.")); return; }
        for (int i=0;i<p.getInventory().items.size();i++) {
            ItemStack disc=p.getInventory().items.get(i);
            if (!disc.isEmpty() && disc.getItem() instanceof RecordItem) {
                String id=BuiltInRegistries.ITEM.getKey(disc.getItem()).toString();
                scanner.getOrCreateTag().putString("LidarDisc",id); disc.shrink(1);
                p.sendSystemMessage(Component.literal("§a[LiDAR] Пластинка установлена: " + id + ". Нажми «Воспроизвести».")); return;
            }
        }
        p.sendSystemMessage(Component.literal("§c[LiDAR] В инвентаре нет музыкальной пластинки."));
    }
    private static void ejectDisc(ServerPlayer p, ItemStack scanner) {
        String id = scanner.getOrCreateTag().getString("LidarDisc");
        if (id.isEmpty()) { p.sendSystemMessage(Component.literal("§e[LiDAR] Слот уже пуст.")); return; }
        var item = BuiltInRegistries.ITEM.get(new ResourceLocation(id));
        if (item == net.minecraft.world.item.Items.AIR) { p.sendSystemMessage(Component.literal("§c[LiDAR] Не удалось извлечь пластинку.")); return; }
        ItemStack disc = new ItemStack(item);
        if (!p.getInventory().add(disc)) p.drop(disc, false);
        scanner.getOrCreateTag().remove("LidarDisc");
        p.sendSystemMessage(Component.literal("§a[LiDAR] Пластинка извлечена."));
    }
    private static void playDisc(ServerPlayer p, ItemStack scanner) {
        String id=scanner.getOrCreateTag().getString("LidarDisc");
        if (id.isEmpty()) { p.sendSystemMessage(Component.literal("§c[LiDAR] Слот пуст. Вставь пластинку.")); return; }
        var item=BuiltInRegistries.ITEM.get(new ResourceLocation(id));
        if (!(item instanceof RecordItem record)) { p.sendSystemMessage(Component.literal("§c[LiDAR] Не удалось прочитать пластинку.")); return; }
        p.level().playSound(null,p.blockPosition(),record.getSound(),SoundSource.RECORDS,4.0F,1.0F);
        p.sendSystemMessage(Component.literal("§b[LiDAR] Воспроизведение: " + id));
    }
}
