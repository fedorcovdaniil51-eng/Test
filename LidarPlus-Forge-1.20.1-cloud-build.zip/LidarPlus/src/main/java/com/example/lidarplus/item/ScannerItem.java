package com.example.lidarplus.item;

import com.example.lidarplus.client.ScannerScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ScannerItem extends Item {
    public ScannerItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) Minecraft.getInstance().setScreen(new ScannerScreen());
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
